var product = [{
    "id": 0,
    "title": "",
    "price": "",
    "description": "",
    "brand": "",
    "image": "https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/No-Image-Placeholder.svg/1665px-No-Image-Placeholder.svg.png"
}, {
    "id": 1,
    "title": "Forte Haircare Kit",
    "price": 9999,
    "description": "Forte Haircare Kit price in Pakistan is Rs. 9,999. Official dealers and providers regulate the retail price of Forte Products in official Price.",
    "brand": "Forte ",
    "image": "img/Cat3/ct1.jpg"
}, {
    "id": 2,
    "title": "Hawtborne HairCare Kit",
    "price": 6299,
    "description": "Hawtborne Haircare Kit price in Pakistan is Rs. 6,299. Official dealers and providers regulate the retail price of Hawtborne Products in official Price.",
    "brand": "Hawtborne",
    "image": "img/Cat3/ct2.jpg"
}, {
    "id": 3,
    "title": "Huron Scalp-Nourishing kit",
    "price": 4499,
    "description": "Huron Scalp-Nourishing Kit price in Pakistan is Rs. 4,499. Official dealers and providers regulate the retail price of Huron Products in official Price.",
    "brand": "Huron",
    "image": "img/Cat3/ct3.jpg"
}, {
    "id": 4,
    "title": "Tresemme Hair Spray",
    "price": 999,
    "description": "Tresemme Hair Spray price in Pakistan is Rs. 999. Official dealers and providers regulate the retail price of Tresemme Products in official Price.",
    "brand": "Tresemme",
    "image": "img/Cat3/ct4.jpg"
}, {
    "id": 5,
    "title": "Forte Strengthening Oil",
    "price": 2199,
    "description": "Forte Strengthening Oil price in Pakistan is Rs. 2,199. Official dealers and providers regulate the retail price of Forte  Products in official Price.",
    "brand": "Forte",
    "image": "img/Cat3/ct5.jpg"
}, {
    "id": 6,
    "title": "Blunt Scalp-Moisturing Kit",
    "price": 5599,
    "description": "Blunt Scalp-Moisturing Kit price in Pakistan is Rs. 5,599. Official dealers and providers regulate the retail price of Blunt Products in official Price.",
    "brand": "blunt",
    "image": "img/Cat3/ct6.jpg"
}, {
    "id": 7,
    "title": "Heo Hair-Nourishing Oil",
    "price": 999,
    "description": "Heo Hair-Nourishing Oil price in Pakistan is Rs. 999. Official dealers and providers regulate the retail price of Heo Products in official Price.",
    "brand": "Heo",
    "image": "img/Cat3/ct7.jpg"
}, {
    "id": 8,
    "title": "DaariMooch Haircare Kit",
    "price": 3399,
    "description": "DaariMooch Haircare Kit price in Pakistan is Rs. 9,999. Official dealers and providers regulate the retail price of DaariMooch Products in official Price.",
    "brand": "DaariMooch",
    "image": "img/Cat3/ct8.jpg"
},








    {
        "id": 10,
        "title": "Remington Hair Dryer",
        "price": 6199,
        "description": "Remington Hair Dryer price in Pakistan is Rs. 6,199. Official dealers and providers regulate the retail price of Remington Products in official Price.",
        "brand": "Remington",
        "image": "img/he/he2.jpg"
    },
    {
        "id": 11,
        "title": "Hairitage Hair Dryer",
        "price": 4499,
        "description": "Hairitage Hair Dryer price in Pakistan is Rs. 4,499. Official dealers and providers regulate the retail price of Hairitage Products in official Price.",
        "brand": "Hairitage",
        "image": "img/he/he3.jpg"
    },
    {
        "id": 12,
        "title": "Elchim Hair Dryer",
        "price": 3899,
        "description": "Elchim Hair Dryer price in Pakistan is Rs. 3,899. Official dealers and providers regulate the retail price of Elchim Products in official Price.",
        "brand": "Elchim",
        "image": "img/he/he4.jpg"
    },
    {
        "id": 13,
        "title": "Uikar Tissue Massager",
        "price": 4499,
        "description": "Uikar Tissue Massager price in Pakistan is Rs. 4,499. Official dealers and providers regulate the retail price of Uikar Products in official Price.",
        "brand": "Uikar",
        "image": "img/he/he5.jpg"
    },
    {
        "id": 14,
        "title": "Theradum Scalp Massager",
        "price": 5899,
        "description": "Theradum Scalp Massager price in Pakistan is Rs. 5,899. Official dealers and providers regulate the retail price of Theradum Products in official Price.",
        "brand": "Theradum",
        "image": "img/he/he6.jpg"
    },
    {
        "id": 15,
        "title": "Eleels Meditive Massager",
        "price": 7399,
        "description": "Eleels Meditive Massager price in Pakistan is Rs. 7,399. Official dealers and providers regulate the retail price of Eleels Products in official Price.",
        "brand": "Eleels",
        "image": "img/he/he7.jpg"
    },
    {
        "id": 16,
        "title": "Beurer Manipol Massager",
        "price": 6199,
        "description": "Beurer Manipol Massager price in Pakistan is Rs. 6,199. Official dealers and providers regulate the retail price of Beurer Products in official Price.",
        "brand": "Beurer",
        "image": "img/he/he8.jpg"
    },
    {
        "id": 17,
        "title": "Hicomb Portable Straightener",
        "price": 5099,
        "description": "Hicomb Portable Straightener price in Pakistan is Rs. 5,099. Official dealers and providers regulate the retail price of Hicomb Products in official Price.",
        "brand": "Hicomb",
        "image": "img/he/he9.jpg"
    },
    {
        "id": 18,
        "title": "Kemei Aqua Straightener",
        "price": 2999,
        "description": "Kemei Aqua Straightener price in Pakistan is Rs. 2,999. Official dealers and providers regulate the retail price of Kemei Products in official Price.",
        "brand": "Kemei",
        "image": "img/he/he10.jpg"
    },
    {
        "id": 19,
        "title": "Remington Slim Straightener",
        "price": 3499,
        "description": "Remington Slim Straightener price in Pakistan is Rs. 3,499. Official dealers and providers regulate the retail price of Remington Products in official Price.",
        "brand": "Remington",
        "image": "img/he/he11.jpg"
    },
    {
        "id": 20,
        "title": "Philips Silk Straightener",
        "price": 6799,
        "description": "Philips Silk Straightener price in Pakistan is Rs. 6,799. Official dealers and providers regulate the retail price of Philips Products in official Price.",
        "brand": "Philips",
        "image": "img/he/he12.jpg"
    },
    {
        "id": 1,
        "title": "Cocco Platinum Trimmer",
        "price": 3499,
        "description": "Cocco Platinum Trimmer price in Pakistan is Rs. 3,499. Official dealers and providers regulate the retail price of Cocco Products in official Price.",
        "brand": "Cocco",
        "image": "img/he/he13.jpg"
    },
    {
        "id": 2,
        "title": "Morphy Richard Trimmer",
        "price": 4899,
        "description": "Morphy Richard Trimmer price in Pakistan is Rs. 4,899. Official dealers and providers regulate the retail price of Morphy Products in official Price.",
        "brand": "Morphy",
        "image": "img/he/he14.jpg"
    },
    {
        "id": 3,
        "title": "Vintage A9 Trimmer",
        "price": 6299,
        "description": "Vintage A9 Trimmer price in Pakistan is Rs. 6,299. Official dealers and providers regulate the retail price of Vintage Products in official Price.",
        "brand": "Vintage",
        "image": "img/he/he15.jpg"
}, {
    "id": 4,
    "title": "Cocco Deluxe Trimmer",
    "price": 5699,
    "description": "Cocco Deluxe Trimmer price in Pakistan is Rs. 5,699. Official dealers and providers regulate the retail price of Cocco Products in official Price.",
    "brand": "Cocco",
    "image": "img/he/he16.jpg"
},









    {
        "id": 5,
        "title": "Royal Anti-Fungus Oil",
        "price": 2399,
        "description": "Royal Anti-Fungus Oil price in Pakistan is Rs. 2,399. Official dealers and warranty providers regulate the retail price of Royal products in official warranty.",
        "brand": "Royal",
        "image": "img/products/f1.jpg"
    },
    {
        "id": 6,
        "title": "Mounia Anti-Dandruff Kit",
        "price": 3499,
        "description": "Mounia Anti-Dandruff Kit price in Pakistan is Rs. 3,499. Official dealers and warranty providers regulate the retail price of Mounia products in official warranty.",
        "brand": "Mounia",
        "image": "img/products/f2.jpg"
    },
    {
        "id": 7,
        "title": "HairAffairs Hair Spray",
        "price": 999,
        "description": "HairAffairs Hair Spray price in Pakistan is Rs. 999. Official dealers and warranty providers regulate the retail price of HairAffairs products in official warranty.",
        "brand": "HairAffairs",
        "image": "img/products/f3.jpg"
    },
    {
        "id": 8,
        "title": "Cureology Shampoo",
        "price": 4499,
        "description": "Cureology Shampoo price in Pakistan is Rs. 4,499. Official dealers and warranty providers regulate the retail price of Cureology products in official warranty.",
        "brand": "Cureology",
        "image": "img/products/f4.jpg"
    },
    {
        "id": 9,
        "title": "Grow Gorgeous Conditioner",
        "price": 3499,
        "description": "Grow Gorgeous Conditioner price in Pakistan is Rs. 3,499. Official dealers and warranty providers regulate the retail price of Grow Gorgeous products in official warranty.",
        "brand": "Grow Gorgeous",
        "image": "img/products/f5.jpg"
    },
    {
        "id": 10,
        "title": "Grow Gorgeous keratin kit",
        "price": 5299,
        "description": "Grow Gorgeous keratin kit price in Pakistan is Rs. 5,299. Official dealers and warranty providers regulate the retail price of Grow Gorgeous products in official warranty.",
        "brand": "Grow Gorgeous",
        "image": "img/products/f6.jpg"
    },
    {
        "id": 11,
        "title": "Grow Gorgeous Shampoo",
        "price": 2999,
        "description": "Grow Gorgeous Shampoo price in Pakistan is Rs. 2,999. Official dealers and warranty providers regulate the retail price of Grow Gorgeous products in official warranty.",
        "brand": "Grow Gorgeous",
        "image": "img/products/f7.jpg"
    },
    {
        "id": 12,
        "title": "Vince Nourishing Oil",
        "price": 1499,
        "description": "Vince Nourishing Oil price in Pakistan is Rs. 1,499. Official dealers and warranty providers regulate the retail price of Vince products in official warranty.",
        "brand": "Vince",
        "image": "img/products/f8.jpg"
    },
    {
        "id": 13,
        "title": "Marula Hair Serum",
        "price": 1999,
        "description": "Marula Hair Serum price in Pakistan is Rs. 1,999. Official dealers and warranty providers regulate the retail price of Marula products in official warranty.",
        "brand": "Marula",
        "image": "img/products/f9.jpg"
    },







    {
        "id": 14,
        "title": "Bondi Boost HairCare Kit",
        "price": 4299,
        "description": "Bondi Boost HairCare Kit price in Pakistan is Rs. 4,299. Official dealers and warranty providers regulate the retail price of Bondi Boost products in official warranty.",
        "brand": "Bondi Boost",
        "image": "img/products/n1.jpg"
    },
    {
        "id": 15,
        "title": "Bondi Boost HG Kit",
        "price": 2999,
        "description": "Bondi Boost HG Kit price in Pakistan is Rs. 2,999. Official dealers and warranty providers regulate the retail price of Bondi Boost products in official warranty.",
        "brand": "Bondi Boost",
        "image": "img/products/n2.jpg"
    },
    {
        "id": 16,
        "title": "Monat Clinical Kit",
        "price": 3999,
        "description": "Monat Clinical Kit price in Pakistan is Rs. 3,999. Official dealers and warranty providers regulate the retail price of Monat products in official warranty.",
        "brand": "Monat",
        "image": "img/products/n3.jpg"
    },
    {
        "id": 17,
        "title": "L'oreal Keratin Kit",
        "price": 5499,
        "description": "L'oreal Keratin Kit price in Pakistan is Rs. 5,499. Official dealers and warranty providers regulate the retail price of L'oreal products in official warranty.",
        "brand": "L'oreal",
        "image": "img/products/n4.jpg"
    },
    {
        "id": 18,
        "title": "Orb Scalp-Nourishing Kit",
        "price": 7999,
        "description": "Orb Scalp-Nourishing Kit price in Pakistan is Rs. 7,999. Official dealers and warranty providers regulate the retail price of Orb products in official warranty.",
        "brand": "Orb",
        "image": "img/products/n5.jpg"
    },
    {
        "id": 18,
        "title": "CH Anti-Graying Kit",
        "price": 5899,
        "description": "CH Anti-Graying Kit price in Pakistan is Rs. 5,899. Official dealers and warranty providers regulate the retail price of CH products in official warranty.",
        "brand": "CH",
        "image": "img/products/n6.jpg"
    },
    {
        "id": 19,
        "title": "Refresh Anti-B Kit",
        "price": 6499,
        "description": "Refresh Anti-B Kit price in Pakistan is Rs. 6,499. Official dealers and warranty providers regulate the retail price of Refresh products in official warranty.",
        "brand": "Refresh",
        "image": "img/products/n7.jpg"
    },
    {
        "id": 19,
        "title": "Mizani ScalpCare Kit",
        "price": 8299,
        "description": "Mizani ScalpCare Kit price in Pakistan is Rs. 8,299. Official dealers and warranty providers regulate the retail price of Mizani products in official warranty.",
        "brand": "Mizani",
        "image": "img/products/n8.jpg"
    },
    {
        "id": 20,
        "title": "Bondi Boost HairCare Kit",
        "price": 4299,
        "description": "Bondi Boost HairCare Kit price in Pakistan is Rs. 4,299. Official dealers and warranty providers regulate the retail price of Bondi Boost products in official warranty.",
        "brand": "Itel",
        "image": "img/products/no2.jpg"
    }]